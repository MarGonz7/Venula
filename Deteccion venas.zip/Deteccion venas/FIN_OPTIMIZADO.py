# -*- coding: utf-8 -*-
"""
Created on Fri May 22 20:21:42 2020

@author: Mariana_
"""
#################### IMPORTO LAS LIBRERIAS
import cv2
import numpy as np
##### LEER IMAGEN EN FORMATO BN
imagen = cv2.imread('im7.jpg')
original = cv2.imread('im7.jpg')
gray=cv2.cvtColor(imagen,cv2.COLOR_BGR2GRAY)
######################EQUALIZACION DE HISTOGRAMA
clahe = cv2.createCLAHE(clipLimit=200.0, tileGridSize=(17,17)) #Equalizacion del Histograma
cl1 = clahe.apply(gray)
cv2.imwrite('eq.jpg',cl1)
##############################################MASCARA QUE BUSCA EL NEGRO
im3 = cv2.imread('eq.jpg')
hsv = cv2.cvtColor(im3, cv2.COLOR_BGR2HSV)
negro_alto = np.array([0,0,0])
gris  = np.array([50,50,100])
mask = cv2.inRange(hsv, negro_alto, gris)
contours1, hierarchy1 = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
############################################KERNELS TRANSFORMACIONES MORFOLOGICAS
artkernel=cv2.getStructuringElement(cv2.MORPH_RECT, (2,2))
artkernel1 = cv2.getStructuringElement(cv2.MORPH_CROSS, (2,2))
##CERRADURA Y APERTURA
closing=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,artkernel)
opening=cv2.morphologyEx(closing,cv2.MORPH_OPEN,artkernel1)
#######################################################ESQUELETIZACION
skeleton=cv2.ximgproc.thinning(opening,cv2.ximgproc.THINNING_ZHANGSUEN)
cv2.imwrite('esqueletizacion.jpg',skeleton)
imagen2 = cv2.imread('esqueletizacion.jpg')
#####################################TRANSOFORMADA DE HOUGH
edges = cv2.Canny(imagen2, 50, 150, apertureSize = 3)
lines = cv2.HoughLinesP(edges, 5, np.pi/180, 10, minLineLength=45, maxLineGap=12)
for line in lines:
    x1, y1, x2, y2 = line[0]
    cv2.line(imagen2, (x1,y1), (x2,y2), (0,255,0), 4, cv2.LINE_AA)   
cv2.imwrite('venas_detectadas.jpg',imagen2)
im3 = cv2.imread('venas_detectadas.jpg')
hsv = cv2.cvtColor(im3, cv2.COLOR_BGR2HSV)
#Rango de colores detectados:
#Verdes:
verde_bajos = np.array([49,50,50])
verde_altos = np.array([107, 255, 255])
#Crear las mascaras
msk = cv2.inRange(hsv, verde_bajos, verde_altos) 
cv2.imwrite('mascara.jpg',msk)
img = cv2.imread('mascara.jpg')
# Convert to greyscale
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# Convert to binary image by thresholding
_, threshold = cv2.threshold(img_gray, 245, 255, cv2.THRESH_BINARY_INV)
# ENCONTRAR CONTORNOS REFERENCIAS CANAL DE OMES,
#######https://theailearner.com/2019/11/22/simple-shape-detection-using-contour-approximation/
contours, _ = cv2.findContours(threshold, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
# APPROXIMAMOS LA CURVA A RECTANGULOS Y CREACION DE LISTAS
valores_centroide_x = []
valores_centroide_y = []
valores_angulos = []

for cnt in contours:
#    epsilon = 0.1*cv2.arcLength(cnt, True)  ############## LO CALCULAMOS PARA QUE LOS CONVIERTA EN RECTANGULOS
#    approx = cv2.approxPolyDP(cnt, epsilon, True)
    rect = cv2.minAreaRect(cnt)    #(x,y),(width,height),theta
    x, y = rect[0] #EXTRAE X Y Y DEL CENTROIDE
    ancho, largo = rect[1] # EXTRAE EL ANCHO Y LARGO
    angle = rect[2] # EXTRAE EL THETA
    cx = int(x)
    cy = int(y)
    valores_centroide_x.append(cx)             ############ APPPEND CENTROIDE
    valores_centroide_y.append(cy)


#VERTICAL Y    
    if ancho < largo:
        if angle == -90:
            new_angle = 90
        else:
            angulo_pos = angle * -1
            new_angle = (2 * angulo_pos) + (90 - angulo_pos)
# HORIZONTAL X
    elif ancho > largo :
        if angle == -90:
            new_angle = 0
        else:
            new_angle = angle * -1
            
    valores_angulos.append(new_angle)                        ######APPPEND ANGULOS
    print (new_angle)
    ang_tx=str(int(new_angle))

    box = cv2.boxPoints(rect) ##############CREA LOS PUNTOS DEL RECTANGULO
    box = np.int0(box)
    
    area = cv2.contourArea(cnt)
    if area > 7000:
        contours.remove(cnt)
    if area < 7000:
        cv2.drawContours(imagen,[box],0,(0,0,255),2)
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(imagen, '{},{}'.format(cx,cy),(cx+15,cy+10), font, 0.5,(0,255,0),1,cv2.LINE_AA)
        cv2.circle(imagen, (cx,cy), 7, (255,0,0), -1)
        cv2.putText(imagen,ang_tx,(cx+15,cy-15),cv2.FONT_HERSHEY_SIMPLEX,0.7,(100,255,255),2) 
cv2.imshow('Original',original)           
cv2.imshow('Contornos',imagen)   
cv2.waitKey(0)
cv2.destroyAllWindows()
